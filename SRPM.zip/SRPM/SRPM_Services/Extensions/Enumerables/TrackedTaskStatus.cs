﻿namespace SRPM_Services.Extensions.Enumerables;

public enum TrackedTaskStatus
{
    Pending,
    Running,
    Completed,
    Cancelled,
    Failed
}