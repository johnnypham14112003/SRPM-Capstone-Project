﻿using System.ComponentModel.DataAnnotations;

namespace SRPM_Services.BusinessModels.ResponseModels
{
    public class RS_SystemConfiguration
    {
        public Guid Id { get; set; }

        public string? ConfigKey { get; set; }
        public string? ConfigValue { get; set; }

        [Required]
        [MaxLength(30)]
        public string ConfigType { get; set; } = null!;

        public string? Description { get; set; }

        [Required]
        public DateTime LastUpdate { get; set; } = DateTime.Now;

        [Required]
        public DateTime CreateDate { get; set; } = DateTime.Now;
    }
}
