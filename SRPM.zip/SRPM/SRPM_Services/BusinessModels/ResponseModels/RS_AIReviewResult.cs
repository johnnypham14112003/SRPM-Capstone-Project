﻿namespace SRPM_Services.BusinessModels.ResponseModels;

public class RS_AIReviewResult
{
    public bool ReviewerResult { get; set; }
    public int TotalRate { get; set; }
    public string Comment { get; set; }
}