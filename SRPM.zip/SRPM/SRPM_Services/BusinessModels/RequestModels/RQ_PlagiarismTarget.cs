﻿namespace SRPM_Services.BusinessModels.RequestModels;

public class RQ_PlagiarismTarget
{
    public Guid ProjectId { get; set; }
    public Guid individualEvalutionId { get; set; }
}
