﻿namespace SRPM_Services.BusinessModels.Others
{
    public class RQ_GoogleLogin
    {
        public string Email { get; set; }
        public string Name { get; set; }
        public string AvatarUrl { get; set; }
        public string SelectedRole { get; set; }
    }
}
