﻿namespace SRPM_Services.BusinessModels.Others;

public class DTO_PasswordEmail
{
    public string UserName { get; set; }
    public string WebsiteURL { get; set; }
    public string OtpCode { get; set; }
}