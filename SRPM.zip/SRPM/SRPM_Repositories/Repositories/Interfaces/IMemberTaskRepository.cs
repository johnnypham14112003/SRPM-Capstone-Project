﻿using SRPM_Repositories.Models;

namespace SRPM_Repositories.Repositories.Interfaces;

public interface IMemberTaskRepository : IGenericRepository<MemberTask>
{
}
