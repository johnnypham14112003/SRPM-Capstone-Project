﻿namespace SRPM_Repositories.Repositories.Interfaces;
public interface ITaskRepository : IGenericRepository<Models.Task>
{
}